import greenfoot.*; 
public class dirt extends platform
{
    public void act()
    {
        super.act();

    }
}
