import greenfoot.*;
public class bulletShowcase extends showcase
{
    public bulletShowcase(){
        getImage().scale(70, 70);
    }
    
    public void act()
    {
        // Add your action code here.
    }
}
