import greenfoot.*;
public class grass extends platform
{
    public void act()
    {
        super.act();

    }
}
