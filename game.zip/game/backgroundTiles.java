import greenfoot.*;
public class backgroundTiles extends entity
{
    public void act()
    {
         super.act();
    }
}
