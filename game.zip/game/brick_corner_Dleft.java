import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class brick_corner_Dleft here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class brick_corner_Dleft extends platform
{
    /**
     * Act - do whatever the brick_corner_Dleft wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        super.act();
    }
}
