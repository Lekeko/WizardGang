import greenfoot.*;
public class carpet extends platform
{
    public void act()
    {
        super.act();
    }
}
