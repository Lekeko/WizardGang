import greenfoot.*;
public class brick extends platform
{
    public void act()
    {
        super.act();
    }
}
