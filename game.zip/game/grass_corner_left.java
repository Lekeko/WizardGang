import greenfoot.*;
public class grass_corner_left extends platform
{
    public void act()
    {
        super.act();
    }
}
