import greenfoot.*;
public class BoomEnemy extends Boom
{
    public BoomEnemy(){
        imagini = new GreenfootImage[][] {
            {
                new GreenfootImage("bullet1_enemy.png"),
                new GreenfootImage("bullet2_enemy.png"),
                new GreenfootImage("bullet3_enemy.png"),
                new GreenfootImage("bullet4_enemy.png"),
                new GreenfootImage("bullet5_enemy.png"),
                new GreenfootImage("bullet6_enemy.png"),
                new GreenfootImage("bullet7_enemy.png")
            }
        };
    }
    public void act()
    {
        
        super.act();
    }
}
