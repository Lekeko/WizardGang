import greenfoot.*;
public class barier extends platform
{
    public void act()
    {
        super.act();
    }
}
