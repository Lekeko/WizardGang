import greenfoot.*;
public class brick_out_left extends platform
{
    public void act()
    {
        super.act();
    }
}
