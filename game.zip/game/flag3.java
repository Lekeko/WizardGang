import greenfoot.*;
public class flag3 extends backgroundTiles
{
    public void act()
    {
        super.act();
    }
}
