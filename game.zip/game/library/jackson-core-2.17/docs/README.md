# Empty!

`/docs/` used to contain Javadocs definitions, but since they can be found from:

   http://www.javadoc.io/doc/com.fasterxml.jackson.core/jackson-core

are no longer stored in	this repo
