import greenfoot.*;
public class all_wood extends platform
{
    public void act()
    {
         super.act();
    }
}
