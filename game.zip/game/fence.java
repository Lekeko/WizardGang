import greenfoot.*;
public class fence extends backgroundTiles
{
    public void act()
    {
        super.act();
    }
}
