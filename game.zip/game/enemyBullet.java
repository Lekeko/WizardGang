import greenfoot.*;
public class enemyBullet extends bullet
{
    public enemyBullet(){
        enemyClass=shiro.class;
        boom=new boomTrump();
    }
    public void act()
    {
        super.act();
    }
}
