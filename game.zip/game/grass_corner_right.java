import greenfoot.*; 
public class grass_corner_right extends platform
{
    public void act()
    {
        super.act();
    }
}
