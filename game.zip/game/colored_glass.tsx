<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="colored_glass" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="images/glass_colored.png" width="32" height="32"/>
</tileset>
