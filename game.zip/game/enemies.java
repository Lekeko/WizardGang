import greenfoot.*;
public class enemies extends collision
{
    public void act()
    {
        super.act();
    }
}
