import greenfoot.*;
public class all_wood2 extends platform
{
    public void act()
    {
         super.act();
    }
}
