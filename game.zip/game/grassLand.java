import greenfoot.*;
public class grassLand extends backgroundTiles
{
    public void act()
    {
         super.act();
    }
}
