import greenfoot.*;
public class flag1 extends backgroundTiles
{
    public void act()
    {
        super.act();
    }
}
