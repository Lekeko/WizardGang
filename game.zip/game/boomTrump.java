import greenfoot.*;
public class boomTrump extends Boom
{
    public boomTrump(){
        imagini = new GreenfootImage[][] {
            {
                new GreenfootImage("ball_impact1.png"),
                new GreenfootImage("ball_impact2.png"),
                new GreenfootImage("ball_impact3.png"),
                new GreenfootImage("ball_impact4.png"),
            }
        };
    }
    public void act()
    {
        
        super.act();
    }
}
