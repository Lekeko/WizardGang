import greenfoot.*; 
public class dash extends Boom
{
    public dash(){
        animateSpeed=5;
        imagini = new GreenfootImage[][] {
            {
                new GreenfootImage("dash1.png"),
                new GreenfootImage("dash2.png"),
                new GreenfootImage("dash3.png"),
                new GreenfootImage("dash4.png"),
            }
        };
    }
    public void act()
    {
       super.act();
    }
}
