import greenfoot.*;
public class GunShowcase extends showcase
{
    public GunShowcase(){
        getImage().rotate(-45);
        setImage(scaleSprite(getImage(),2));
    }
    
    public void act()
    {
        // Add your action code here.
    }
}
