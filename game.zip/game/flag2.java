import greenfoot.*;
public class flag2 extends backgroundTiles
{
    public void act()
    {
        super.act();
    }
}
